var audio = new Audio('audio/music.mp3');
audio.play();
