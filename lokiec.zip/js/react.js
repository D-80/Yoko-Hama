//<KeyBinding onKey={ (e) => { console.log(e.keyCode) } } />

//<KeyBinding onKey={ (e) => { console.log(e.keyCode) } } type='keyup' elem={ window } />

//const h1 = <h1>Hello world</h1>;

/*
// First set up animation 
Animated.timing(
    this.state.spinValue,
  {
    toValue: 1,
    duration: 3000,
    easing: Easing.linear
  }
).start()

// Second interpolate beginning and end values (in this case 0 and 1)
const spin = this.state.spinValue.interpolate({
  inputRange: [0, 1],
  outputRange: ['0deg', '360deg']
})
*/

